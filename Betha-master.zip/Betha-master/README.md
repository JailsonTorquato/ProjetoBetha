## Betha Test

[![Say Thanks!](https://img.shields.io/badge/Say%20Thanks-!-1EAEDB.svg)](https://saythanks.io/to/gabrielesteveslima)

### Purpose

Project for the selective process of Betha systems.

### Getting Started 

#### Installing dependencies

| Dependency | :link: |
| --- | --- |
| .NET Core SDK for build apps| [download](https://www.microsoft.com/net/download) |
| Visual Studio Code | [download](https://code.visualstudio.com) |
| PostgreSQL or use In Memory(Test only) | [download](https://www.postgresql.org/download/) |
| Postman | [download](https://www.getpostman.com/downloads/) |

#### :running: :dash: Running :dash: :dash:  

* Change the code below for your postgreSQL settings:

Betha.WebApi.Database:
```csharp
        protected override void OnConfiguring (DbContextOptionsBuilder optionsBuilder) 
            => optionsBuilder.UseNpgsql ("Host=my_host;Database=my_database;Username=my_username;Password=my_password");
```

* Perform the migration routine for database structure and initial data load

```csharp
dotnet ef database update
```

* Its Done! Just Run

```csharp
dotnet run
```

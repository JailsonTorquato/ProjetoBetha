using System;
using System.Collections.Generic;
using Betha.WebApi.Generics;

namespace Betha.WebApi.Models {
    public class Product : Entity<Guid> {
        public string Name { get; set; }
        public ICollection<Quote> Quotes { get; set; }
    }
}
using System;
using Betha.WebApi.Generics;
using Betha.WebApi.Interfaces;

namespace Betha.WebApi.Models {
    public class Supplier : Entity<Guid> {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
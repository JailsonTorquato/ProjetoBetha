using System;
using Betha.WebApi.Generics;

namespace Betha.WebApi.Models {
    public class Quote : Entity<Guid> {
        public Product Product { get; set; }
        public Guid ProductId { get; set; }
        public Supplier Supplier { get; set; }
        public Guid SupplierId { get; set; }
        public decimal Price { get; set; }
    }
}
using Betha.WebApi.Models;

namespace Betha.WebApi.Interfaces.Repositories {
    public interface IQuoteRepository : IRepository<Quote> { }
}
using Betha.WebApi.Models;

namespace Betha.WebApi.Interfaces.Repositories {
    public interface ISupplierRepository : IRepository<Supplier> {

    }
}
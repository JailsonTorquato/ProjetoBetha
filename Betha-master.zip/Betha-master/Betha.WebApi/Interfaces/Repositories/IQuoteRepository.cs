using Betha.WebApi.Models;

namespace Betha.WebApi.Interfaces.Repositories {
    public interface IProductRepository : IRepository<Product> { }
}
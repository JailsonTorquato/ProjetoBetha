using System;
using System.Linq;
using System.Threading.Tasks;

namespace Betha.WebApi.Interfaces {
    public interface IRepository<T> where T : class, IEntity<Guid> {
        IQueryable<T> GetAll ();
        Task<T> GetById (Guid id);
        Task Create (T entity);
        Task Update (Guid id, T entity);
        Task Delete (Guid id);
    }
}
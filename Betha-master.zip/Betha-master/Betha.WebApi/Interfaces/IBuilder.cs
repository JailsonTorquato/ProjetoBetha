using System;
using Betha.WebApi.Generics;

namespace Betha.WebApi.Interfaces {
    public interface IBuilder<T> {
        T Build ();
    }
}
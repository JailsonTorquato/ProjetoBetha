using System;
using Betha.WebApi.Generics;
using Betha.WebApi.Models;

namespace Betha.WebApi.Builders {
    public class QuoteBuilder : Builder<Quote> {
        public Product Product { get; set; }
        public Guid ProductId { get; set; }
        public Supplier Supplier { get; set; }
        public Guid SupplierId { get; set; }
        public decimal Price { get; set; }

        public QuoteBuilder () {
            Id = Guid.NewGuid ();
        }

        public QuoteBuilder WithProduct (Product product) {
            this.Product = product;
            return this;
        }

        public QuoteBuilder WithSupplier (Supplier supplier) {
            this.Supplier = supplier;
            return this;
        }

        public QuoteBuilder WithPrice (decimal price) {
            this.Price = price;
            return this;
        }

        public override Quote Build () {
            return new Quote () {
                Id = this.Id,
                    Product = this.Product,
                    ProductId = this.Product.Id,
                    Supplier = this.Supplier,
                    SupplierId = this.Supplier.Id,
                    Price = this.Price
            };
        }
    }
}
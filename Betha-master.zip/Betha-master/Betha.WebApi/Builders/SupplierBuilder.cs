using System;
using Betha.WebApi.Generics;
using Betha.WebApi.Models;

namespace Betha.WebApi.Builders {
    public class SupplierBuilder : Builder<Supplier> {
        public string Name { get; private set; }
        public string Email { get; private set; }

        public SupplierBuilder () {
            this.Id = Guid.NewGuid ();
        }

        public SupplierBuilder WithName (string name) {
            this.Name = name;
            return this;
        }

        public SupplierBuilder WithEmail (string email) {
            this.Email = email;
            return this;
        }

        public override Supplier Build () {
            return new Supplier () {
                Id = this.Id,
                    Name = this.Name,
                    Email = this.Email
            };
        }
    }
}
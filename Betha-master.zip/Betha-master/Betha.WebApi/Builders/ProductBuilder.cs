using System;
using System.Collections.Generic;
using Betha.WebApi.Generics;
using Betha.WebApi.Models;

namespace Betha.WebApi.Builders {
    public class ProductBuilder : Builder<Product> {
        public string Name { get; set; }
        public ICollection<Quote> Quotes { get; set; }

        public ProductBuilder () {
            this.Id = Guid.NewGuid ();
        }

        public ProductBuilder WithName (string name) {
            this.Name = name;
            return this;
        }

        public ProductBuilder WithQuotes (List<Quote> quotes) {
            this.Quotes = quotes;
            return this;
        }

        public override Product Build () {
            return new Product () {
                Id = this.Id,
                    Name = this.Name,
                    Quotes = this.Quotes
            };
        }
    }
}
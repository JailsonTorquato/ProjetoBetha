using System;
using System.Linq;
using System.Threading.Tasks;
using Betha.WebApi.Database;
using Betha.WebApi.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Generics {
    public abstract class Repository<T> : IRepository<T> where T : class, IEntity<Guid> {
        private readonly BethaContext bethaContext;

        public Repository (BethaContext bethaContext) {
            this.bethaContext = bethaContext;
        }

        public async Task Create (T entity) {
            await bethaContext.Set<T> ().AddAsync (entity);
            await bethaContext.SaveChangesAsync ();
        }

        public async Task Delete (Guid id) {
            var entity = await GetById (id);
            bethaContext.Set<T> ().Remove (entity);
            await bethaContext.SaveChangesAsync ();
        }

        public IQueryable<T> GetAll () {
            return this.bethaContext.Set<T> ().AsNoTracking ();
        }

        public async Task<T> GetById (Guid id) {
            return await bethaContext.Set<T> ()
                .AsNoTracking ()
                .FirstOrDefaultAsync (e => e.Id == id);
        }

        public async Task Update (Guid id, T entity) {
            bethaContext.Set<T> ().Update (entity);
            await bethaContext.SaveChangesAsync ();
        }
    }
}
using System;
using Betha.WebApi.Interfaces;

namespace Betha.WebApi.Generics {
    public abstract class Builder<T> : IBuilder<T>, IEntity<Guid> {
        public Guid Id { get; set; }

        public virtual T Build () {
            throw new System.NotImplementedException ();
        }
    }
}
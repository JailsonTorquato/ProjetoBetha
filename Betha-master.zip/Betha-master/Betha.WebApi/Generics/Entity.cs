using System.ComponentModel.DataAnnotations;
using Betha.WebApi.Interfaces;

namespace Betha.WebApi.Generics {
    public abstract class Entity<T> : IEntity<T> {
        public T Id { get; set; }
    }
}
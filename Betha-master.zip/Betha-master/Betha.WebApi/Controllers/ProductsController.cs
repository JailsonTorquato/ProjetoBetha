using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Controllers {
    [Route ("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase {
        private readonly IProductRepository repository;

        public ProductsController (IProductRepository repository) {
            this.repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetAll () {
            var products = await this.repository.GetAll ().ToListAsync ();
            return Ok (products);
        }

        [HttpGet ("{productId:guid}")]
        public async Task<ActionResult<Product>> GetById (Guid productId) {
            var product = await this.repository.GetById (productId);
            return Ok (product);
        }

        [HttpPost]
        public async Task<ActionResult<Product>> Create ([FromBody] Product product) {
            await this.repository.Create (product);
            return Created (string.Empty, product);
        }

        [HttpDelete ("{productId:guid}")]
        public async Task<ActionResult<Product>> Delete (Guid productId) {
            await this.repository.Delete (productId);
            return NoContent ();
        }

        [HttpPut ("{productId:guid}")]
        public async Task<ActionResult<Product>> Update (Guid productId, [FromBody] Product product) {
            product.Id = productId;
            await this.repository.Update (product.Id, product);
            return Ok ();
        }
    }
}
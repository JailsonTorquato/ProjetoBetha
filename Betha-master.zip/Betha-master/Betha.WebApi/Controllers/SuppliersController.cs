using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Betha.WebApi.Database;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Controllers {
    [Route ("api/[controller]")]
    [ApiController]
    public class SuppliersController : ControllerBase {
        private readonly ISupplierRepository repository;

        public SuppliersController (ISupplierRepository repository) {
            this.repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetAll () {
            var suppliers = await this.repository.GetAll ().ToListAsync ();
            return Ok (suppliers);
        }

        [HttpGet ("{supplierId:guid}")]
        public async Task<ActionResult<Supplier>> GetById (Guid supplierId) {
            var supplier = await this.repository.GetById (supplierId);
            return Ok (supplier);
        }

        [HttpPost]
        public async Task<ActionResult<Supplier>> Create ([FromBody] Supplier supplier) {
            await this.repository.Create (supplier);
            return Created (string.Empty, supplier);
        }

        [HttpDelete ("{supplierId:guid}")]
        public async Task<ActionResult<Supplier>> Delete (Guid supplierId) {
            await this.repository.Delete (supplierId);
            return NoContent ();
        }

        [HttpPut ("{supplierId:guid}")]
        public async Task<ActionResult<Supplier>> Update (Guid supplierId, [FromBody] Supplier supplier) {
            supplier.Id = supplierId;
            await this.repository.Update (supplier.Id, supplier);
            return Ok ();
        }
    }
}
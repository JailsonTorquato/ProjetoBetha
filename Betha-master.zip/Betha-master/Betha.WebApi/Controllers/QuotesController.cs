using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Controllers {
    [Route ("api/[controller]")]
    [ApiController]
    public class QuotesController : ControllerBase {
        private readonly IQuoteRepository repository;

        public QuotesController (IQuoteRepository repository) {
            this.repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Quote>>> GetAll () {
            var quotes = await this.repository.GetAll ().ToListAsync ();
            return Ok (quotes);
        }

        [HttpGet ("{quoteId:guid}")]
        public async Task<ActionResult<Quote>> GetById (Guid quoteId) {
            var quote = await this.repository.GetById (quoteId);
            return Ok (quote);
        }

        [HttpPost]
        public async Task<ActionResult<Quote>> Create ([FromBody] Quote quote) {
            await this.repository.Create (quote);
            return Created (string.Empty, quote);
        }

        [HttpDelete ("{quoteId:guid}")]
        public async Task<ActionResult<Quote>> Delete (Guid quoteId) {
            await this.repository.Delete (quoteId);
            return NoContent ();
        }

        [HttpPut ("{quoteId:guid}")]
        public async Task<ActionResult<Quote>> Update (Guid quoteId, [FromBody] Quote quote) {
            quote.Id = quoteId;
            await this.repository.Update (quote.Id, quote);
            return Ok ();
        }
    }
}
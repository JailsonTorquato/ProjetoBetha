using System;
using Betha.WebApi.Builders;
using Betha.WebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Database.Data.Seed {
    public static class ModelBuilderExtensions {
        public static void Seed (this ModelBuilder modelBuilder) {
            var bethaSystems = new Supplier ();
            var thomsonreuters = new Supplier ();
            modelBuilder.Entity<Supplier> ().HasData (
                thomsonreuters = new SupplierBuilder ()
                .WithName ("Thsomson Reuters")
                .WithEmail ("thomsonreuters@email.com")
                .Build (),
                bethaSystems = new SupplierBuilder ()
                .WithName ("Thsomson Reuters")
                .WithEmail ("thomsonreuters@email.com")
                .Build ()
            );

            var product = new Product ();
            modelBuilder.Entity<Product> ().HasData (
                product = new ProductBuilder ()
                .WithName ("System ABC")
                .Build ()
            );

            modelBuilder.Entity<Quote> ().HasData (
                new Quote () {
                    Id = Guid.NewGuid (),
                        ProductId = product.Id,
                        SupplierId = bethaSystems.Id,
                        Price = new decimal (10000.50)
                },
                new Quote () {
                    Id = Guid.NewGuid (),
                        ProductId = product.Id,
                        SupplierId = thomsonreuters.Id,
                        Price = new decimal (50000.50)
                }
            );
        }
    }
}
using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Betha.WebApi.Database.Data.Migrations {
    public partial class CreateTables : Migration {
        protected override void Up (MigrationBuilder migrationBuilder) {
            migrationBuilder.CreateTable (
                name: "Products",
                columns : table => new {
                    Id = table.Column<Guid> (nullable: false),
                        Name = table.Column<string> (nullable: true)
                },
                constraints : table => {
                    table.PrimaryKey ("PK_Products", x => x.Id);
                });

            migrationBuilder.CreateTable (
                name: "Suppliers",
                columns : table => new {
                    Id = table.Column<Guid> (nullable: false),
                        Name = table.Column<string> (nullable: true),
                        Email = table.Column<string> (nullable: true)
                },
                constraints : table => {
                    table.PrimaryKey ("PK_Suppliers", x => x.Id);
                });

            migrationBuilder.CreateTable (
                name: "Quotes",
                columns : table => new {
                    Id = table.Column<Guid> (nullable: false),
                        ProductId = table.Column<Guid> (nullable: false),
                        SupplierId = table.Column<Guid> (nullable: false),
                        Price = table.Column<decimal> (nullable: false)
                },
                constraints : table => {
                    table.PrimaryKey ("PK_Quotes", x => x.Id);
                    table.ForeignKey (
                        name: "FK_Quotes_Products_ProductId",
                        column : x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete : ReferentialAction.Cascade);
                    table.ForeignKey (
                        name: "FK_Quotes_Suppliers_SupplierId",
                        column : x => x.SupplierId,
                        principalTable: "Suppliers",
                        principalColumn: "Id",
                        onDelete : ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData (
                table: "Products",
                columns : new [] { "Id", "Name" },
                values : new object[] { new Guid ("e578f989-3a91-41f4-9015-4b6d39538eff"), "System ABC" });

            migrationBuilder.InsertData (
                table: "Suppliers",
                columns : new [] { "Id", "Email", "Name" },
                values : new object[, ] { { new Guid ("a1b6b6d9-d1eb-49b9-984c-756e5a5e11d7"), "thomsonreuters@email.com", "Thsomson Reuters" }, { new Guid ("fa08ac9d-e9bb-4a4a-b7ca-cb431486e5ed"), "thomsonreuters@email.com", "Thsomson Reuters" }
                });

            migrationBuilder.InsertData (
                table: "Quotes",
                columns : new [] { "Id", "Price", "ProductId", "SupplierId" },
                values : new object[, ] { { new Guid ("59369759-6734-4ac6-944b-4a0731276567"), 50000.5m, new Guid ("e578f989-3a91-41f4-9015-4b6d39538eff"), new Guid ("a1b6b6d9-d1eb-49b9-984c-756e5a5e11d7") }, { new Guid ("d4234f30-167c-4efb-b1c2-28974323343f"), 10000.5m, new Guid ("e578f989-3a91-41f4-9015-4b6d39538eff"), new Guid ("fa08ac9d-e9bb-4a4a-b7ca-cb431486e5ed") }
                });

            migrationBuilder.CreateIndex (
                name: "IX_Quotes_ProductId",
                table: "Quotes",
                column: "ProductId");

            migrationBuilder.CreateIndex (
                name: "IX_Quotes_SupplierId",
                table: "Quotes",
                column: "SupplierId");
        }

        protected override void Down (MigrationBuilder migrationBuilder) {
            migrationBuilder.DropTable (
                name: "Quotes");

            migrationBuilder.DropTable (
                name: "Products");

            migrationBuilder.DropTable (
                name: "Suppliers");
        }
    }
}
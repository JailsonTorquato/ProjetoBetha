using Betha.WebApi.Generics;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;

namespace Betha.WebApi.Database.Repositories {
    public class QuoteRepository : Repository<Quote>, IQuoteRepository {
        public QuoteRepository (BethaContext bethaContext) : base (bethaContext) { }
    }
}
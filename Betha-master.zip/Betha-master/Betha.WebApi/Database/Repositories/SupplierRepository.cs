using Betha.WebApi.Generics;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;

namespace Betha.WebApi.Database.Repositories {
    public class SupplierRepository : Repository<Supplier>, ISupplierRepository {
        public SupplierRepository (BethaContext bethaContext) : base (bethaContext) { }
    }
}
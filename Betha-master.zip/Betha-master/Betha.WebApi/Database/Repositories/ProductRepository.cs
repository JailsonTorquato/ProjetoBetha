using Betha.WebApi.Generics;
using Betha.WebApi.Interfaces.Repositories;
using Betha.WebApi.Models;

namespace Betha.WebApi.Database.Repositories {
    public class ProductRepository : Repository<Product>, IProductRepository {
        public ProductRepository (BethaContext bethaContext) : base (bethaContext) { }
    }
}
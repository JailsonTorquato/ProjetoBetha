using System;
using Betha.WebApi.Database.Data.Seed;
using Betha.WebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace Betha.WebApi.Database {
    public class BethaContext : DbContext {

        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Quote> Quotes { get; set; }

        public BethaContext (DbContextOptions<BethaContext> options) : base (options) { }

        protected override void OnConfiguring (DbContextOptionsBuilder optionsBuilder) => optionsBuilder.UseNpgsql ("Host=my_host;Database=my_database;Username=my_username;Password=my_password");

        protected override void OnModelCreating (ModelBuilder modelBuilder) => modelBuilder.Seed ();
    }
}